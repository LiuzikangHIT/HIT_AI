package cn.edu.hit.servlet;

import cn.edu.hit.dao.UserDao;
import cn.edu.hit.dao.impl.UserDaoImpl;
import cn.edu.hit.entity.User;

import jakarta.servlet.http.Cookie;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.net.URLEncoder;

@WebServlet(name = "LoginServlet", value = "/login-servlet")
public class LoginServlet extends HttpServlet {
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        UserDao dao = new UserDaoImpl();
        response.setContentType("text/html");
        User user = dao.getUserByName(request.getParameter("username"));
        if(user.getPassword().equals(request.getParameter("password"))){
            if(request.getParameter("rememberMe") != null){
                Cookie usernameCookie = new Cookie("username", URLEncoder.encode(user.getUsername(), "UTF-8"));
                Cookie passwordCookie = new Cookie("password", URLEncoder.encode(user.getPassword(), "UTF-8"));
                usernameCookie.setMaxAge(60 * 60 * 24 * 7);
                passwordCookie.setMaxAge(60 * 60 * 24 * 7);
                response.addCookie(usernameCookie);
                response.addCookie(passwordCookie);
            }
            HttpSession session = request.getSession();
            session.setAttribute("IsLogin", true);
            response.sendRedirect("student.jsp");
        } else {
            HttpSession session = request.getSession();
            session.setAttribute("IsLogin", false);
            response.sendRedirect("login.jsp");
        }
    }
}
