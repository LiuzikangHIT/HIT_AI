package cn.edu.hit.entity;

import java.sql.Date;

public class Student {
    private String sid;
    private String name;
    private String gender;
    private int age;
    private String birthday;

    public Student(String sid, String name, String gender, int age, String birthday) {
        this.sid = sid;
        this.name = name;
        this.gender = gender;
        this.age = age;
        this.birthday = birthday;
    }

    public String getSid() { return sid; }

    public String getName() {
        return name;
    }

    public String getGender() {
        return gender;
    }

    public int getAge() {
        return age;
    }

    public String getBirthday() {
        return birthday;
    }

    public void setSid(String sid) { this.sid = sid; }

    public void setName(String name) { this.name = name; }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }
}
