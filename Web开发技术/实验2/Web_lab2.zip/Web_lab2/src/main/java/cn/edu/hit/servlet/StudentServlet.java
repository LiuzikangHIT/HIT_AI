package cn.edu.hit.servlet;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import cn.edu.hit.dao.StudentDao;
import cn.edu.hit.dao.impl.StudentDaoImpl;
import cn.edu.hit.entity.Student;

import java.io.IOException;

@WebServlet(name = "StudentServlet", value = "/student-servlet")
public class StudentServlet extends HttpServlet {
    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        doPost(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("text/html");
        StudentDao dao = new StudentDaoImpl();
        String action = request.getParameter("action");
        String sid = request.getParameter("sid");

        if(action.equals("addStudent")){
            String name = request.getParameter("name");
            String gender = request.getParameter("gender");
            int age = Integer.parseInt(request.getParameter("age"));
            String birthday = request.getParameter("birthday");

            Student student = new Student(sid, name, gender, age, birthday);
            dao.addStudent(student);

        } else if(action.equals("deleteStudent")){
            dao.deleteStudent(sid);

        } else if(action.equals("modifyStudent")){
            String name = request.getParameter("name");
            String gender = request.getParameter("gender");
            int age = Integer.parseInt(request.getParameter("age"));
            String birthday = request.getParameter("birthday");

            Student student = new Student(sid, name, gender, age, birthday);
            dao.modifyStudent(student);
        }
        response.sendRedirect("student.jsp");
    }
}
