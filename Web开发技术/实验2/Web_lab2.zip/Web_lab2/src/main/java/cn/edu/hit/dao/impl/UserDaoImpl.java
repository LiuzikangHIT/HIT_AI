package cn.edu.hit.dao.impl;

import cn.edu.hit.dao.UserDao;
import cn.edu.hit.entity.User;
import cn.edu.hit.util.DbUtil;

import java.sql.*;

public class UserDaoImpl implements UserDao {
    @Override
    public User getUserByName(String username) {
        String password;
        String sql = "select * from \"user\" where username = ?";
        Connection con = DbUtil.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, username);
            rs = ps.executeQuery();
            if (rs.next()) {
                password = rs.getString("password");
                User user = new User(rs.getString("username"), password);
                return user;
            }
            return null;
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        } finally {
            DbUtil.close(rs, ps, con);
        }
    }
}
