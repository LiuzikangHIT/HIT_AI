package cn.edu.hit.test;

import cn.edu.hit.dao.impl.StudentDaoImpl;
import cn.edu.hit.entity.Student;
import cn.edu.hit.dao.StudentDao;

public class Hello {
    public static void main(String[] args) {
        Student student = new Student("4", "John", "m", 20, "2004-08-18");
        StudentDao dao = new StudentDaoImpl();
        dao.addStudent(student);
    }
}
