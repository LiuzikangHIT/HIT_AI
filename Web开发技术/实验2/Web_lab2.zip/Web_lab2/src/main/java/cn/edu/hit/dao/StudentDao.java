package cn.edu.hit.dao;

import cn.edu.hit.entity.Student;
import java.util.List;

public interface StudentDao {
    void addStudent(Student student);
    void deleteStudent(String sid);
    void modifyStudent(Student student);
    List<Student> getAllStudent(String sql);
    List<Student> getByName(String name);
    Student getStudent(String sid);

}
