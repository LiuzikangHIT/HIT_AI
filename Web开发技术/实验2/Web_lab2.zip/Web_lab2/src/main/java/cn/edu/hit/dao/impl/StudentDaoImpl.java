package cn.edu.hit.dao.impl;

import cn.edu.hit.dao.StudentDao;
import cn.edu.hit.entity.Student;
import cn.edu.hit.util.DbUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

public class StudentDaoImpl implements StudentDao {
    @Override
    public void addStudent(Student student) {
        String sid = student.getSid();
        String name = student.getName();
        String gender = student.getGender();
        int age = student.getAge();
        String birthday = student.getBirthday();

        String sql = "insert into public.student values(?,?,?,?,?)";
        Connection con = DbUtil.getConnection();
        PreparedStatement ps = null;
        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, sid);
            ps.setString(2, name);
            ps.setString(3, gender);
            ps.setInt(4, age);
            ps.setDate(5, Date.valueOf(birthday));
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DbUtil.close(ps, con);
        }
    }

    @Override
    public void modifyStudent(Student student) {
        String sid = student.getSid();
        String name = student.getName();
        String gender = student.getGender();
        int age = student.getAge();
        String birthday = student.getBirthday();
        String sql = "update public.student set name=?, gender=?, age=?, birthday=? where sid=?";

        Connection con = DbUtil.getConnection();
        PreparedStatement ps = null;
        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, name);
            ps.setString(2, gender);
            ps.setInt(3, age);
            ps.setDate(4, Date.valueOf(birthday));
            ps.setString(5, sid);
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DbUtil.close(ps, con);
        }
    }

    @Override
    public void deleteStudent(String sid) {
        String sql = "delete from public.student where sid=?";
        Connection con = DbUtil.getConnection();
        PreparedStatement ps = null;
        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, sid);
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DbUtil.close(ps, con);
        }
    }

    @Override
    public List<Student> getAllStudent(String sql) {
        String sid;
        String name;
        String gender;
        int age;
        String birthday;

        Connection con = DbUtil.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<Student> list = new ArrayList<>();
        try {
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();

            while (rs.next()) {
                sid = rs.getString("sid");
                name = rs.getString("name");
                gender = rs.getString("gender");
                age = rs.getInt("age");
                birthday = rs.getDate("birthday").toString();

                Student student = new Student(sid, name, gender, age, birthday);
                list.add(student);
            }
            return list;
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        } finally {
            DbUtil.close(rs, ps, con);
        }
    }

    @Override
    public Student getStudent(String sid) {
        String name;
        String gender;
        int age;
        String birthday;

        String sql = "select * from public.student where sid=?";
        Connection con = DbUtil.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, sid);
            rs = ps.executeQuery();
            if (rs.next()) {
                name = rs.getString("name");
                gender = rs.getString("gender");
                age = rs.getInt("age");
                birthday = rs.getDate("birthday").toString();

                Student student = new Student(rs.getString("sid"), name, gender, age, birthday);
                return student;
            }
            return null;
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        } finally {
            DbUtil.close(rs, ps, con);
        }
    }

    @Override
    public List<Student> getByName(String name) {
        String sid;
        String gender;
        int age;
        String birthday;

        String sql = "select * from student where name like '%' + name + '%'";
        Connection con = DbUtil.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<Student> list = new ArrayList<>();
        try {
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();

            while (rs.next()) {
                sid = rs.getString("sid");
                name = rs.getString("name");
                gender = rs.getString("gender");
                age = rs.getInt("age");
                birthday = rs.getString("birthday");

                Student student = new Student(sid, name, gender, age, birthday);
                list.add(student);
            }
            return list;
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        } finally {
            DbUtil.close(rs, ps, con);
        }
    }
}
