package cn.edu.hit.dao;

import cn.edu.hit.entity.User;

import java.util.List;

public interface UserDao {
    User getUserByName(String username);
}
