<script setup>
import axios from 'axios';
import { ref } from 'vue';
import { useRouter } from 'vue-router';
import { ElMessage, ElMessageBox } from 'element-plus';

let username = ref('')
let password = ref('')
const router = useRouter()

// 用户登录
function userLogin() {
    axios.get(`http://localhost:8080/user/get?username=${username.value}`)
    .then((res) => {
        if(res.data.code == 200 && res.data.user.password == password.value) { 
            sessionStorage.setItem("username", username.value)
            sessionStorage.setItem("flag", 0)
            router.replace('/home')
        } else {
            ElMessage.error("用户名或密码错误！")
        }
    })
    .catch((err) => {
        console.log(err)
        ElMessage.error("用户不存在！")
    })
}

// 管理员登录
function adminLogin() {
    axios.get(`http://localhost:8080/admin/get?adminname=${username.value}`)
    .then((res) => {
        if(res.data.code == 200 && res.data.user.password == password.value) {
            sessionStorage.setItem("username", username.value)
            sessionStorage.setItem("flag", 1)
            router.replace('/home')
        } else {
            ElMessage.error("用户名或密码错误！")
        }
    })
    .catch((err) => {
        console.log(err)
        ElMessage.error("用户不存在！")
    })
}

// 注册
function SignUp() {
    sessionStorage.setItem("username", '')
    router.replace('/signup')
}

</script>

<template>
    <div class="login-container">
      <el-input v-model="username" style="width: 240px" placeholder="请输入用户名" clearable/> <br>
      <el-input v-model="password" type="password" style="width: 240px" placeholder="请输入密码" show-password/> <br>
      <div style="display: flex; justify-content: space-between; margin-top: 10px;">
        <el-button type="primary" style="width: 90px" @click="userLogin">登录</el-button>
        <el-button type="primary" style="width: 140px" @click="adminLogin">管理员登录</el-button>
      </div>
      <div style="display: flex; justify-content: space-between; margin-top: 10px;">
        <el-button type="text" style="font-size: 12px; margin-right: 120px" @click="SignUp">没有账号？点此注册</el-button>
      </div>
    </div>
  </template>
    
  <style scoped>  
  .login-container {  
    display: flex;
    flex-direction: column;
    align-items: center;        /* 垂直居中 */
    justify-content: center;    /* 水平居中*/
    height: 100vh;
  }
  </style>