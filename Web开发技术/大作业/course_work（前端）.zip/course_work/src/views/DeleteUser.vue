<template>
    <el-table :data="users" style="width: 25%">
        <el-table-column prop="username" label="用户名" width="220"/>
        <el-table-column>
            <template #default="scope">
                <el-button size="small" type="danger" @click="handleDelete(scope.$index)">删除</el-button>
            </template>
        </el-table-column>
    </el-table>
    <el-button type="primary" style="margin-top:10px" @click="router.replace('/home')">返回</el-button>
</template>

<script lang="ts" setup>
import { useRouter } from 'vue-router';
import { ElMessage, ElMessageBox } from 'element-plus';
import { ref, onMounted } from 'vue';
import axios from 'axios';

const router = useRouter()
const users = ref([])

function handleDelete(index) {
    let username = users.value[index].username
    ElMessageBox.confirm(
        '确定要删除用户吗？',
        '删除确认',
    {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
    }
    )
    .then(() => {
        axios.get(`http://localhost:8080/user/delete?username=${username}`)
        .then((res) => {
            if(res.data.code == 200) {
                router.go(0)
                ElMessage.success(res.data.msg)
            }
        })
        .catch((err) => {
                console.log(err)
            })
    })
    .catch(() => {})
}

onMounted(() => {
    axios.get("http://localhost:8080/user/getAll")
    .then((res) => {
        if(res.data.code == 200) {
            users.value = res.data.user
        }
    })
    .catch((err) => {
        console.log(err)
    })
})

</script>
