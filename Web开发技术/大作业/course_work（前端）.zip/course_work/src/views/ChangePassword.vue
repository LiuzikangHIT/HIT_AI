<template>
    <el-form :model="user" label-width="80" style="max-width: 300px">
        <el-form-item label="用户名">
            <el-input v-model="user.username" disabled/>
        </el-form-item>
        <el-form-item label="新密码">
            <el-input v-model="user.password_new" type="password" show-password/>
        </el-form-item>
        <el-form-item label="确认密码">
            <el-input v-model="user.password_confirm" type="password" show-password/>
        </el-form-item>
        <el-form-item>
            <el-button type="primary" style="width:100px" @click="onSubmit">提交</el-button>
            <el-button style="width:100px" @click="router.replace('/home')">取消</el-button>
        </el-form-item>
    </el-form>
</template>
  
<script lang="ts" setup>
import { reactive, ref } from 'vue';
import axios from 'axios';
import { useRouter } from 'vue-router';
import { ElMessage } from 'element-plus';

const router = useRouter()
const username = sessionStorage.getItem("username")
const flag = sessionStorage.getItem("flag")
const user = reactive({
    username: username,
    password_new: '',
    password_confirm: ''
})

const onSubmit = () => {
    // 验证两次密码是否一致
    if(user.password_new!= user.password_confirm) {
        ElMessage.error("两次密码不一致")
        return
    }
    // 存入新密码
    let url = ``
    if(flag == '0') {
        url = `http://localhost:8080/user/update?username=${user.username}&password=${user.password_new}`
    }
    else {
        url = `http://localhost:8080/admin/update?adminname=${user.username}&password=${user.password_new}`
    }
    axios.get(url)
    .then((res) => {
        if(res.data.code == 200) {
            ElMessage.success(res.data.msg)
            router.replace('/login')
        }
    })
    .catch((err) => {
        console.log(err)
    })
}

</script>
