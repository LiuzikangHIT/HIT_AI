<template>
    <el-select v-model="module_chosen" placeholder="请选择板块分类" style="max-width: 240px; margin-bottom:10px">
        <el-option
            v-for="item in modules"
            :key="item.moduleid"
            :label="item.modulename"
            :value="item.moduleid"
            @click = "getModuleID(item.moduleid)">
        </el-option>
    </el-select><br>
    <el-input
        type="textarea"
        :autosize="{ minRows: 4, maxRows: 10}"
        placeholder="请输入内容"
        v-model="post.content"
        style="max-width: 240px; margin-bottom:10px">
    </el-input>
    <el-form-item>
        <el-button type="primary" style="width:100px" @click="onSubmit">发帖</el-button>
        <el-button style="width:100px" @click="router.replace('/home')">取消</el-button>
    </el-form-item>
</template>
  
<script lang="ts" setup>
import { reactive, ref, onMounted } from 'vue';
import axios from 'axios';
import { useRouter } from 'vue-router';
import { ElMessage } from 'element-plus';

const router = useRouter()
const username = sessionStorage.getItem("username")
const postnum = sessionStorage.getItem("postnum")

const module_chosen = ref('')
const modules = ref([])

let post = reactive({
    username: username,
    content: '',
    postid: Number(postnum) + 1,
    moduleid: ''
})

function getModuleID(moduleid) {
    // console.log('用户选择的值:', moduleid);
    post.moduleid = moduleid;
}

const onSubmit = () => {
    // console.log(user)
    axios.get(`http://localhost:8080/post/add?username=${post.username}&content=${post.content}&postid=${post.postid}&likecount=0&moduleid=${post.moduleid}`)
    .then((res) => {
        if(res.data.code == 200) {
            ElMessage.success(res.data.msg)
            router.replace('/home')
        }
    })
    .catch((err) => {
        console.log(err)
    })
}

onMounted(() => {
    axios.get("http://localhost:8080/module/getAll")
    .then((res) => {
        if(res.data.code == 200) {
            modules.value = res.data.module
        }
    })
    .catch((err) => {
        console.log(err)
    })
})

</script>
