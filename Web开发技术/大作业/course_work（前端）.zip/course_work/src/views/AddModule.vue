<template >
    <el-form :model="Module" label-width="80" style="max-width: 300px">
        <el-form-item label="板块名">
            <el-input v-model="Module.modulename" clearable/>
        </el-form-item>
        <el-form-item>
            <el-button type="primary" style="width:100px" @click="onSubmit">添加</el-button>
            <el-button style="width:100px" @click="router.replace('/home')">取消</el-button>
        </el-form-item>
    </el-form>
</template>
  
<script lang="ts" setup>
import { reactive } from 'vue';
import axios from 'axios';
import { useRouter } from 'vue-router';
import { ElMessage } from 'element-plus';

const router = useRouter()
const modulenum = sessionStorage.getItem("modulenum")
const Module = reactive({
    moduleid: Number(modulenum) + 1,
    modulename: ''
})

const onSubmit = () => {
    // console.log(user)
    axios.get(`http://localhost:8080/module/add?moduleid=${Module.moduleid}&modulename=${Module.modulename}`)
    .then((res) => {
        if(res.data.code == 200) {
            ElMessage.success(res.data.msg)
            router.replace('/home')
        }
    })
    .catch((err) => {
        console.log(err)
    })
}

</script>
