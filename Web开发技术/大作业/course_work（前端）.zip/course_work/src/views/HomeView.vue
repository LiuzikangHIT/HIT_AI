<script setup>

import { ref, onMounted } from 'vue';
import axios  from 'axios';
import { useRouter } from 'vue-router';
import { ElMessage, ElMessageBox } from 'element-plus';
import { Edit, Comment, Star, Delete } from '@element-plus/icons-vue'

//板块示例
const module_chosen = ref()
const modules = ref([])

//帖子示例
const post = ref([])

//评论示例
const comment = ref([])

//用于计数帖子到底时加载
const count = ref()
count.value = sessionStorage.getItem("postnum")

//管理员删除按钮的显示与隐藏，通过v-if
const adminflag = sessionStorage.getItem("flag")
function adminDelete() {
  if (adminflag == 1) {
    return true;
  } else {
    return false;
  }
}

// 获取全部板块或某个板块的帖子
function getPost(i) {
  if (module_chosen.value == null) {
    // console.log(module_chosen.value);
    return true;
  }
  if (post.value[i-1].moduleid == module_chosen.value) {
    // console.log(module_chosen.value);
    return true;
  }
  return false;
}

//将评论显示到对应帖子，如果不匹配，则不渲染DOM，以此达到不显示
function PostComment(j, i) {
  if (comment.value[j-1].postid==post.value[i-1].postid) {
    return true;
  }
  else {
    return false;
  }
}

const router = useRouter()
//发帖按钮响应
function SendPost() {
  router.push('/addpost')
}

//点赞按钮响应
const Likeflag = ref(Array.from({length: sessionStorage.getItem("postnum")}, () => 0))
console.log(Likeflag.value)
function Likeit(i) {
  if (Likeflag.value[i-1] == 0) {
    post.value[i-1].likecount += 1;
    Likeflag.value[i-1] += 1;
    axios.get(`http://localhost:8080/post/update?postid=${post.value[i-1].postid}&flag=1`).then((res) => {})
  }
  else {
    post.value[i-1].likecount -= 1;
    Likeflag.value[i-1] -= 1;
    axios.get(`http://localhost:8080/post/update?postid=${post.value[i-1].postid}&flag=0`).then((res) => {})
  }
}


//评论按钮响应
function Remarkit(i) {
  router.push(
    {
      path: '/addcomment',
      query: {postid: post.value[i-1].postid}
    })
}

// 删除帖子
function DeletePost(postid) {
  ElMessageBox.confirm(
  '确定要删除数据吗？',
  '是否删除',
  {
    confirmButtonText: '确认',
    cancelButtonText: '取消',
    type: 'warning',
  }
  ).then(() =>{
    axios.get(`http://localhost:8080/post/delete?postid=${postid}`)
    .then((res) => {
      if(res.data.code == 200) {
        ElMessage.success(res.data.msg)
        router.go(0);
      }
    })
    .catch((err) => {
      console.log(err)
    })
  })
}

//从后端获取数据
onMounted(() => {
    axios.get("http://localhost:8080/module/getAll")
    .then((res) => {
        if(res.data.code == 200) {
          modules.value = res.data.module
          sessionStorage.setItem("modulenum", modules.value.length)
        }
    })
    .catch((err) => {
        console.log(err)
    })
    axios.get("http://localhost:8080/post/getAll")
    .then((res) => {
        if(res.data.code == 200) {
          post.value = res.data.post
          console.log(post.value)
          sessionStorage.setItem("postnum", post.value.length)
        }
    })
    .catch((err) => {
        console.log(err)
    })
    axios.get("http://localhost:8080/comment/getAll")
    .then((res) => {
        if(res.data.code == 200) {
          comment.value = res.data.comment
          sessionStorage.setItem("commentnum", comment.value.length)
        }
    })
    .catch((err) => {
        console.log(err)
    })
})

</script>


<style>
  .infinite-list {
    height: 600px;
    width: 100%;
    padding: 0;
    margin: 0;
    list-style: none;
  }
  .infinite-list .infinite-list-item {
    display: grid;
    height: 60%;
    border-radius: 4px;
    background: var(--el-color-primary-light-8);
    margin: 16px;
    color: var(--el-color-info-dark-2);
  }
  .item-data {
    display: grid;
    margin: 10px;
  }
  .backgroundcolor {
    border-radius: 4px;
    color: black;
    background-color: rgb(255, 245, 245);
  }
  .scrollbar-demo-item {
    display: flex;
    align-items: center;
    height: flex;
    margin-top: 2px;
    text-align: left;
    border-radius: 4px;
    background: var(--el-color-primary-light-9);
    color: rgb(53, 51, 51);
  }
  .mx-1 {
    margin-left: 10px;
    color: black;
    display: flex;
    align-items: center;
  }
  .selector {
    margin-left: 16px;
  }
</style>


<template>
  <el-select v-model="module_chosen" placeholder="请选择板块" style="width: 240px" class="selector" clearable>
    <el-option
      v-for="item in modules"
      :key="item.moduleid"
      :label="item.modulename"
      :value="item.moduleid"
    />
  </el-select>
  <el-button type="primary" :icon="Edit" @click="SendPost" style="margin-left: 16px">发帖</el-button>
  <el-button type="primary" @click="router.replace('/changepassword')">修改密码</el-button>
  <el-button type="primary" :icon="Edit" @click="router.replace('/addmodule')" v-if="adminDelete()">添加板块</el-button>
  <el-button type="warning" :icon="Delete" @click="router.replace('/deleteuser')" v-if="adminDelete()">删除用户</el-button>
  <el-button type="warning" :icon="Delete" @click="router.replace('/deletemodule')" v-if="adminDelete()">删除板块</el-button>
  <br><br>
  <ul v-if="post.length > 0" class="infinite-list" style="overflow: auto">
    <template v-for="i in post.length" :key="i">
      <li class="infinite-list-item" v-if="getPost(i)">
        <div class="mx-1">
          <el-text size="large" class="mx-1">{{ post[i-1].username }}</el-text>
        </div>
        <div class="item-data">
          <el-scrollbar height="120px" class="backgroundcolor">
            {{ post[i-1].content }}
          </el-scrollbar>
          <div style="margin-top: 5px;">
            <el-tag>{{ post[i-1].likecount }}</el-tag>
            <el-button type="success" :icon="Star"  @click="Likeit(i)" circle />
            <el-button type="primary" :icon="Comment"  @click="Remarkit(i)" circle />
            <el-button type="danger" :icon="Delete" @click="DeletePost(post[i-1].postid)" circle v-if="adminDelete()"></el-button>
          </div>
          <el-scrollbar height="120px">
            <template v-for="j in comment.length" :key="j">
              <p v-if="PostComment(j, i)" class="scrollbar-demo-item">{{ comment[j-1].username }}：{{ comment[j-1].content }}</p>  
            </template> 
          </el-scrollbar>
        </div>
      </li>
    </template>
  </ul>
</template>
