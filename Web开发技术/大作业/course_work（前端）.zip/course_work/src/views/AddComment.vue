<template>
    <el-text class="mx-1">{{}}</el-text>
    <el-input
        type="textarea"
        v-model="comment.content"
        maxlength="200"
        :autosize="{ minRows: 4, maxRows: 10}"
        style="max-width: 360px; margin-bottom:10px"
        placeholder="请输入评论内容"
        show-word-limit>
    </el-input>
    <el-form-item>
        <el-button type="primary" style="width:100px" @click="onSubmit">确定</el-button>
        <el-button style="width:100px" @click="router.replace('/home')">取消</el-button>
    </el-form-item>
</template>
  
<script lang="ts" setup>
import { reactive } from 'vue';
import axios from 'axios';
import { useRouter } from 'vue-router';

const router = useRouter()
const route = router.currentRoute.value
const username = sessionStorage.getItem("username")
const { postid } = route.query
const commentnum = sessionStorage.getItem("commentnum")

let comment = reactive({
    commentid: Number(commentnum) + 1,
    content: '',
    postid: postid,
    username: username
})

const onSubmit = () => {
    // console.log(user)
    axios.get(`http://localhost:8080/comment/add?commentid=${comment.commentid}&content=${comment.content}&postid=${comment.postid}&username=${comment.username}`)
    .then((res) => {
        if(res.data.code == 200) {
            // ElMessage.success(res.data.msg)
            router.replace('/home')
        }
    })
    .catch((err) => {
        console.log(err)
    })
}

</script>
