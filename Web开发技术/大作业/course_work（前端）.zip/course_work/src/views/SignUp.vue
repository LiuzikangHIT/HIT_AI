<template>
    <div class="login-container">
        <el-form :model="user" label-width="80" style="max-width: 300px">
            <el-form-item label="用户名">
                <el-input v-model="user.username" clearable/>
            </el-form-item>
            <el-form-item label="密码">
                <el-input v-model="user.password" type="password" show-password/>
            </el-form-item>
            <el-form-item label="确认密码">
                <el-input v-model="user.password_confirm" type="password" show-password/>
            </el-form-item>
            <el-form-item>
                <el-button type="primary" style="width:100px" @click="onSubmit">注册</el-button>
                <el-button style="width:100px" @click="resetForm">重置</el-button><br>
                <el-button type="text" style="font-size: 12px" @click="router.replace('/login')">已有帐号？去登录</el-button>
            </el-form-item>
        </el-form>
    </div>
</template>
  
<script lang="ts" setup>
import { reactive } from 'vue';
import axios from 'axios';
import { useRouter } from 'vue-router';
import { ElMessage } from 'element-plus';

const router = useRouter()
const user = reactive({
    username: '',
    password: '',
    password_confirm: ''
})

const onSubmit = () => {
    if(user.password!= user.password_confirm) {
        ElMessage.error("两次密码不一致")
        return
    }
    console.log(user)
    axios.get(`http://localhost:8080/user/add?username=${user.username}&password=${user.password}`)
    .then((res) => {
        if(res.data.code == 200) {
            ElMessage.success(res.data.msg)
            router.replace('/login')
        }
        else if(res.data.code == 400)
        {
            ElMessage.error(res.data.msg)
            resetForm()
        }
    })
    .catch((err) => {
        console.log(err)
    })
}

const resetForm = () => {
    user.username = ''
    user.password = ''
    user.password_confirm = ''
}
</script>
