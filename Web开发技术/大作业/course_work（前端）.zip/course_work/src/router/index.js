import { createRouter, createWebHistory } from 'vue-router'
import HomeView from '../views/HomeView.vue'
import LoginView from '../views/LoginView.vue'
import SignUp from '../views/SignUp.vue'
import ChangePassword from '../views/ChangePassword.vue'
import DeleteUser from '../views/DeleteUser.vue'
import Deletemodule from '../views/DeleteModule.vue'
import AddModule from '../views/AddModule.vue'
import AddPost from '../views/AddPost.vue'
import AddComment from '../views/AddComment.vue'


const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/home',
      name: 'home',
      component: HomeView
    },
    {
      path: '/login',
      name: 'login',
      component: LoginView
    },
    {
      path: '/signup',
      name: 'signup',
      component: SignUp
    },
    {
      path: '/changepassword',
      name: 'changepassword',
      component: ChangePassword
    },
    {
      path: '/deleteuser',
      name: 'deleteuser',
      component: DeleteUser
    },
    {
      path: '/deletemodule',
      name: 'deletemodule',
      component: Deletemodule
    },
    {
      path: '/addmodule',
      name: 'addmodule',
      component: AddModule
    },
    {
      path: '/addpost',
      name: 'addpost',
      component: AddPost
    },
    {
      path: '/addcomment',
      name: 'addcomment',
      component: AddComment
    }
  ]
})

router.beforeEach((to, from, next) => {
  if(to.path == '/login') {
    next()
  } else {
    const username = sessionStorage.getItem("username")
    if(username == null) {
      next('/login')
    } else {
      next()
    }
  }
})
export default router