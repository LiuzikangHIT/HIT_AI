package com.example.controller;

import com.example.entity.User;
import com.example.mapper.UserMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/user")
@CrossOrigin
public class UserController {
    @Autowired
    private UserMapper userMapper;
    @GetMapping("/get")
    @ResponseBody
    public Map<String,Object> getUser(@RequestParam("username") String username){
        Map<String,Object> json = new HashMap<>();
        json.put("code",200);
        json.put("user",userMapper.selectById(username));
        return json;
    }
    @GetMapping("/add")
    @ResponseBody
    public Map<String,Object> addUser(@RequestParam("username") String username,@RequestParam("password") String password){
        Map<String,Object> json = new HashMap<>();
        if(userMapper.selectById(username)!=null){
            json.put("code",400);
            json.put("msg","username already exists");
            return json;
        }
        User user = new User(username,password);
        userMapper.insert(user);
        json.put("code",200);
        json.put("msg","success");
        return json;
    }
    @GetMapping("/delete")
    @ResponseBody
    public Map<String,Object> deleteUser(@RequestParam("username") String username){
        Map<String,Object> json = new HashMap<>();
        userMapper.deleteById(username);
        json.put("code",200);
        json.put("msg","success");
        return json;
    }
    @GetMapping("/update")
    @ResponseBody
    public Map<String,Object> updateUser(@RequestParam("username") String username,@RequestParam("password") String password){
        Map<String,Object> json = new HashMap<>();
        User user = new User(username,password);
        userMapper.updateById(user);
        json.put("code",200);
        json.put("msg","success");
        return json;
    }
    @GetMapping("/getAll")
    @ResponseBody
    public Map<String,Object> getAllUser(){
        Map<String,Object> json = new HashMap<>();
        json.put("code",200);
        json.put("user",userMapper.selectList(null));
        return json;
    }
}
