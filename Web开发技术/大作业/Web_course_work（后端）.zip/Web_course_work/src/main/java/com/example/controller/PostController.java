package com.example.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.example.entity.Comment;
import com.example.entity.Post;
import com.example.mapper.CommentMapper;
import com.example.mapper.PostMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/post")
@CrossOrigin
public class PostController {
    @Autowired
    private PostMapper postMapper;
    @Autowired
    private CommentMapper commentMapper;
    @GetMapping("/getAll")
    @ResponseBody
    public Map<String,Object> getAll(){
        Map<String,Object> json = new HashMap<>();
        json.put("code",200);
        json.put("post",postMapper.selectList(null));
        return json;
    }
    @GetMapping("/getbymoduleid")
    @ResponseBody
    public Map<String,Object> getByModuleId(@RequestParam("moduleid") String moduleId){
        Map<String,Object> json = new HashMap<>();
        json.put("code",200);
        QueryWrapper<Post> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("moduleid",moduleId);
        json.put("post",postMapper.selectList(queryWrapper));
        return json;
    }
    @GetMapping("/add")
    @ResponseBody
    public Map<String,Object> add(@RequestParam("username") String username,@RequestParam("content") String content,@RequestParam("postid") String postid,@RequestParam("likecount") int likecount,@RequestParam("moduleid") String moduleid){
        Map<String,Object> json = new HashMap<>();
        Post post = new Post(postid,content,username,likecount,moduleid);
        postMapper.insert(post);
        json.put("code",200);
        json.put("msg","success");
        return json;
    }
    @GetMapping("/delete")
    @ResponseBody
    public Map<String,Object> delete(@RequestParam("postid") String postid){
        Map<String,Object> json = new HashMap<>();

        postMapper.deleteById(postid);
        QueryWrapper<Comment> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("postid",postid);
        commentMapper.delete(queryWrapper);
        json.put("code",200);
        json.put("msg","success");
        return json;
    }
    @GetMapping("/update")
    @ResponseBody
    public Map<String,Object> update(@RequestParam("postid") String postid,@RequestParam("flag") int flag){
        System.out.println(postid);
        Map<String,Object> json = new HashMap<>();
        Post post = postMapper.selectById(postid);
        if(flag==1){
            post.likecount ++;
        }else if(flag==0){
            post.likecount --;
        }
        postMapper.updateById(post);
        json.put("code",200);
        json.put("msg","success");
        return json;
    }
}
