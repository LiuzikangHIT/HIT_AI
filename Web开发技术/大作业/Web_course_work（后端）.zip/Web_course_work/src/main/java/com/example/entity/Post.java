package com.example.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@TableName(value = "posts", autoResultMap = true)
public class Post {
    @TableId(value = "postid", type = IdType.ASSIGN_ID)
    String postid;
    String content;
    String username;
    public int likecount;
    String moduleid;
}
