package com.example.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.example.entity.Comment;
import com.example.entity.Post;
import com.example.mapper.CommentMapper;
import com.example.mapper.PostMapper;
import com.example.mapper.UserMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/comment")
@CrossOrigin
public class CommentController {
    @Autowired
    private CommentMapper commentMapper;
    @Autowired
    private UserMapper userMapper;
    @Autowired
    private PostMapper postMapper;
    @GetMapping("/getAll")
    @ResponseBody
    public Map<String,Object> getAll(){
        Map<String,Object> json = new HashMap<>();
        json.put("code",200);
        json.put("comment",commentMapper.selectList(null));
        return json;
    }
    @GetMapping("/getbypostid")
    @ResponseBody
    public Map<String,Object> getByPostId(@RequestParam("postid") String postid){
        Map<String,Object> json = new HashMap<>();
        json.put("code",200);
        QueryWrapper<Comment> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("postid",postid);
        json.put("comment",commentMapper.selectList(queryWrapper));
        return json;
    }
    @GetMapping("/add")
    @ResponseBody
    public Map<String,Object> add(@RequestParam String commentid,@RequestParam String content,@RequestParam String postid,@RequestParam String username){
        System.out.println(commentid);
        Map<String,Object> json = new HashMap<>();
        Comment comment = new Comment(commentid,content,postid,username);
        commentMapper.insert(comment);
        json.put("code",200);
        json.put("msg","success");
        return json;
    }
    @GetMapping("/delete")
    @ResponseBody
    public Map<String,Object> deleteUser(@RequestParam("username") String username){
        Map<String,Object> json = new HashMap<>();
        userMapper.deleteById(username);

        QueryWrapper<Post> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("username",username);
        postMapper.delete(queryWrapper);

        QueryWrapper<Comment> queryWrapper1 = new QueryWrapper<>();
        queryWrapper1.eq("username",username);
        commentMapper.delete(queryWrapper1);

        json.put("code",200);
        json.put("msg","success");
        return json;
    }
    @GetMapping("/update")
    @ResponseBody
    public Map<String,Object> update(@RequestParam String commentid){
        Map<String,Object> json = new HashMap<>();
        Comment comment = commentMapper.selectById(commentid);
        commentMapper.updateById(comment);
        json.put("code",200);
        json.put("msg","success");
        return json;
    }
}
