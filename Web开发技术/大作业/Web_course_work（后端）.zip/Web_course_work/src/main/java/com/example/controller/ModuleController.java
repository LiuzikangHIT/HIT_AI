package com.example.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.example.entity.Comment;
import com.example.entity.Module;
import com.example.entity.Post;
import com.example.mapper.CommentMapper;
import com.example.mapper.ModuleMapper;
import com.example.mapper.PostMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/module")
@CrossOrigin
public class ModuleController {
    @Autowired
    private ModuleMapper moduleMapper;
    @Autowired
    private PostMapper postMapper;
    @Autowired
    private CommentMapper commentMapper;
    @GetMapping("/getAll")
    @ResponseBody
    public Map<String,Object> getAll(){
        Map<String,Object> json = new HashMap<>();
        json.put("code",200);
        json.put("module", moduleMapper.selectList(null));
        return json;
    }
    @GetMapping("/add")
    @ResponseBody
    public Map<String,Object> add(@RequestParam("moduleid") String moduleid,@RequestParam("modulename") String modulename){
        Map<String,Object> json = new HashMap<>();
//        json.put("code",200);
        moduleMapper.insert(new Module(moduleid,modulename));
        json.put("code",200);
        json.put("msg","success");
        return json;
    }
    @GetMapping("/delete")
    @ResponseBody
    public Map<String,Object> delete(@RequestParam("moduleid") String moduleid){
        Map<String,Object> json = new HashMap<>();
        json.put("code",200);
        moduleMapper.deleteById(moduleid);

        QueryWrapper<Post> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("moduleid",moduleid);
        postMapper.selectList(queryWrapper).forEach(post -> {
            postMapper.deleteById(post.getPostid());
            QueryWrapper<Comment> queryWrapper1 = new QueryWrapper<>();
            queryWrapper1.eq("postid",post.getPostid());
            commentMapper.delete(queryWrapper1);
        });
        json.put("code",200);
        json.put("msg","success");
        return json;
    }
}
