package com.example.controller;

import com.example.entity.Administrator;
import com.example.mapper.AdministratorMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/admin")
@CrossOrigin
public class AdministratorController {
    @Autowired
    private AdministratorMapper administratorMapper;
    @GetMapping("/get")
    @ResponseBody
    public Map<String,Object> getUser(@RequestParam("adminname") String adminid){
        Map<String,Object> json = new HashMap<>();
        json.put("code",200);
        json.put("user",administratorMapper.selectById(adminid));
        return json;
    }
    @GetMapping("/update")
    @ResponseBody
    public Map<String,Object> updateUser(@RequestParam("adminname") String adminid, @RequestParam("password") String password){
        Map<String,Object> json = new HashMap<>();
        Administrator administrator = new Administrator(adminid,password);
        administratorMapper.updateById(administrator);
        json.put("code",200);
        json.put("msg","success");
        return json;
    }
    @GetMapping("/delete")
    @ResponseBody
    public Map<String,Object> deleteUser(@RequestParam("adminname") String adminid){
        Map<String,Object> json = new HashMap<>();
        administratorMapper.deleteById(adminid);
        json.put("code",200);
        json.put("msg","success");
        return json;
    }
    @GetMapping("/add")
    @ResponseBody
    public Map<String,Object> addUser(@RequestParam("adminname") String adminid, @RequestParam("password") String password){
        Map<String,Object> json = new HashMap<>();
        Administrator administrator = new Administrator(adminid,password);
        administratorMapper.insert(administrator);
        json.put("code",200);
        json.put("msg","success");
        return json;
    }
}
