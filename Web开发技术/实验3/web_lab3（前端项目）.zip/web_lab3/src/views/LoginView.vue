<script setup>
import axios from 'axios';
import qs from 'querystring';
import { ref } from 'vue';
import { useRouter } from 'vue-router';

let username = ref('')
let password = ref('')
const router = useRouter()
function handleLogin() {
let user = {
    username: username.value,
    password: password.value
}   
axios.post("http://localhost:8080/login", qs.stringify(user))
.then((res) => {
    // console.log(res.data)
    sessionStorage.setItem("username", username)
    if(res.data.code == 200){ 
        router.replace('/')
    } else {
        alert('用户名或密码错误！')
    }
})
.catch((err) => {
    console.log(err)
})
}
</script>

<template>
    <el-input v-model="username" style="width: 240px" placeholder="请输入用户名" clearable/> <br>
    <el-input v-model="password" type='password' style="width: 240px" placeholder="请输入密码" show-password/> <br>
    <el-button type="primary" @click="handleLogin">登录</el-button>
</template>
