<template>
    <el-table :data="students" style="width: 100%">
        <el-table-column fixed prop="sid" label="学号" width="150"/>
        <el-table-column prop="name" label="姓名" width="120" />
        <el-table-column prop="gender" label="性别" width="120"/>
        <el-table-column prop="age" label="年龄" width="120"/>
        <el-table-column prop="birthday" label="生日" width="120"/>
        <el-table-column fixed="right" label="操作" width="120">
            <template #default="scope">
                <el-button link type="primary" size="small" @click="handleModify(scope.$index)">修改</el-button>
                <el-button link type="primary" size="small" @click="handleDelete(scope.$index)">删除</el-button>
            </template>
        </el-table-column>
    </el-table><br>
    <el-button type="info" size="small" @click="router.replace('/add')">添加学生</el-button>
</template>
  
<script lang="ts" setup>
import { useRouter } from 'vue-router';
import { ElMessage, ElMessageBox } from 'element-plus';
import { ref, onMounted } from 'vue';
import axios from 'axios';

const router = useRouter()
const students = ref([])
function handleModify(index) {
    router.replace({
          path:'/modify',
          query:{
            sid: students.value[index].sid,
            name: students.value[index].name,
            gender: students.value[index].gender,
            age: students.value[index].age,
            birthday: students.value[index].birthday
          }
        })
}
function handleDelete(index) {
    let sid = students.value[index].sid
    ElMessageBox.confirm(
        '确定要删除数据吗？',
        '删除确认',
    {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
    }
    )
    .then(() => {
        axios.delete(`http://localhost:8080/student/${sid}`)
        .then((res) => {
            if(res.data.code == 200) {
                router.go(0)
                ElMessage.success(res.data.msg)
            }
        })
        .catch((err) => {
             console.log(err)
         })
    })
    .catch(() => {})
}
onMounted(() => {
    axios.get("http://localhost:8080/student/list")
    .then((res) => {
        students.value = res.data
    })
    .catch((err) => {
        console.log(err)
    })
})

</script>
