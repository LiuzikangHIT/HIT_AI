<template>
    <el-form :model="student" label-width="64" style="max-width: 300px">
        <el-form-item label="学号">
            <el-input v-model="student.sid" clearable/>
        </el-form-item>
        <el-form-item label="姓名">
            <el-input v-model="student.name" clearable/>
        </el-form-item>
        <el-form-item label="性别">
            <el-select v-model="student.gender" placeholder="请选择">
                <el-option label="男" value="m"/>
                <el-option label="女" value="f"/>
            </el-select>
        </el-form-item>
        <el-form-item label="年龄">
            <el-input v-model="student.age" clearable/>
        </el-form-item>
        <el-form-item label="生日">
            <el-col :span="24">
                <el-date-picker v-model="student.birthday" type="date" style="width: 100%" value-format="YYYY-MM-DD"/>
            </el-col>
        </el-form-item>
        <el-form-item>
            <el-button type="primary" @click="onSubmit">提交</el-button>
            <el-button @click="router.replace('/')">取消</el-button>
        </el-form-item>
    </el-form>
</template>
  
<script lang="ts" setup>
import { reactive } from 'vue';
import axios from 'axios';
import qs from 'querystring';
import { useRouter } from 'vue-router';
import { ElMessage } from 'element-plus';

const router = useRouter()
const student = reactive({
    sid: '',
    name: '',
    gender: '',
    age: '',
    birthday: '',
})
const onSubmit = () => {
    console.log(student)
    axios.post("http://localhost:8080/student/add", qs.stringify(student))
    .then((res) => {
        if(res.data.code == 200) {
            ElMessage.success(res.data.msg)
            router.replace('/')
        }
    })
    .catch((err) => {
        console.log(err)
    })
}
</script>
