package cn.edu.hit.web_lab3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebLab3ApplicationTests {

    @Test
    void contextLoads() {
    }

}
