package cn.edu.hit.web_lab3.mapper;

import cn.edu.hit.web_lab3.entity.Student;
import org.apache.ibatis.annotations.*;

import java.sql.Date;
import java.util.List;

@Mapper
public interface StudentMapper {
    @Select("select * from students order by sid")
    public List<Student> findAll();
    @Insert("insert into students(sid,name,gender,age,birthday) values(#{sid},#{name},#{gender},#{age},#{birthday})")
    void add(String sid, String name, String gender, int age, Date birthday);
    @Update("update students set name=#{name},gender=#{gender},age=#{age},birthday=#{birthday} where sid=#{sid}")
    void modify(String sid, String name, String gender, int age, Date birthday);
    @Delete("delete from students where sid=#{sid}")
    void delete(String sid);

}
