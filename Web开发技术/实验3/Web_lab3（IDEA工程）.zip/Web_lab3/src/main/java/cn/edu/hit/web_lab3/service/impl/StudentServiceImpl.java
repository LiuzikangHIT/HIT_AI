package cn.edu.hit.web_lab3.service.impl;

import cn.edu.hit.web_lab3.entity.Student;
import cn.edu.hit.web_lab3.mapper.StudentMapper;
import cn.edu.hit.web_lab3.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.Date;
import java.util.List;

@Service
public class StudentServiceImpl implements StudentService{
    @Autowired
    private StudentMapper studentMapper;
    @Override
    public List<Student> findAll() {
        return studentMapper.findAll();
    }
    @Override
    public void add(String sid, String name, String gender, int age, Date birthday) {
        studentMapper.add(sid, name, gender, age, birthday);
    }
    @Override
    public void modify(String sid, String name, String gender, int age, Date birthday) {
        studentMapper.modify(sid, name, gender, age, birthday);
    }
    @Override
    public void delete(String sid) {
        studentMapper.delete(sid);
    }
}
