package cn.edu.hit.web_lab3.controller;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;
import cn.edu.hit.web_lab3.util.Result;

@RestController
@CrossOrigin
public class UserController {
    @PostMapping("/login")
    public Result login(String username, String password) {
        if(username.equals("admin") && password.equals("123")) {
            return Result.success("OK");
        } else {
            return Result.fail("Error");
        }
    }
}
