package cn.edu.hit.web_lab3.service;

import cn.edu.hit.web_lab3.entity.Student;

import java.sql.Date;
import java.util.List;

public interface StudentService {
    List<Student> findAll();
    void add(String sid, String name, String gender, int age, Date birthday);
    void modify(String sid, String name, String gender, int age, Date birthday);
    void delete(String sid);
}
