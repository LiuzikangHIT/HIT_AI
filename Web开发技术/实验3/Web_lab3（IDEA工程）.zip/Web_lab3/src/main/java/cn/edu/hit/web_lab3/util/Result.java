package cn.edu.hit.web_lab3.util;

import lombok.Data;
import lombok.Getter;

@Getter
@Data
public class Result {
    private int code;
    private String msg;

    public Result(int code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public static Result success(String msg) {
        return new Result(200, msg);
    }

    public static Result fail(String msg) {
        return new Result(400, msg);
    }
}
