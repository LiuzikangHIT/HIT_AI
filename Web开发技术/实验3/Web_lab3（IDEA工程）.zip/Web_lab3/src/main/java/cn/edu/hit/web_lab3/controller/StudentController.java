package cn.edu.hit.web_lab3.controller;

import cn.edu.hit.web_lab3.entity.Student;
import cn.edu.hit.web_lab3.service.StudentService;
import cn.edu.hit.web_lab3.util.Result;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.sql.Date;
import java.util.List;

@RestController
@CrossOrigin
@RequestMapping("/student")
public class StudentController {
    @Autowired
    private StudentService studentService;
    @GetMapping("/list")
    public List<Student> findAll() {
//        System.out.println(studentService.findAll());
        return studentService.findAll();
    }
    @PostMapping("/add")
    public Result add(String sid, String name, String gender, String age, String birthday) {
//        System.out.println(sid);
        studentService.add(sid, name, gender, Integer.parseInt(age), Date.valueOf(birthday));
        return Result.success("添加成功");
    }
    @PostMapping("/modify")
    public Result modify(String sid, String name, String gender, String age, String birthday) {
        studentService.modify(sid, name, gender, Integer.parseInt(age), Date.valueOf(birthday));
        return Result.success("修改成功");
    }
    @DeleteMapping("/{sid}")
    public Result delete(@PathVariable String sid) {
        studentService.delete(sid);
        return Result.success("已删除");
    }
}